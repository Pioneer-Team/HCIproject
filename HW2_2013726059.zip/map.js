//적용되지 않는 소스


var mapDiv = document.getElementById('map');


var mapOptions = {
    center: new naver.maps.LatLng(37.3595704, 127.105399),
    zoom: 10
};

var map = new naver.maps.Map('map', mapOptions);
